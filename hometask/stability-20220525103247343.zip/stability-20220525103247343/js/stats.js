var stats = {
    type: "GROUP",
name: "Global Information",
path: "",
pathFormatted: "group_missing-name-b06d1",
stats: {
    "name": "Global Information",
    "numberOfRequests": {
        "total": "157443",
        "ok": "157443",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2276",
        "ok": "2276",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles1": {
        "total": "207",
        "ok": "207",
        "ko": "-"
    },
    "percentiles2": {
        "total": "242",
        "ok": "242",
        "ko": "-"
    },
    "percentiles3": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles4": {
        "total": "425",
        "ok": "425",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 157157,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 204,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 82,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "40.515",
        "ok": "40.515",
        "ko": "-"
    }
},
contents: {
"group_login-99dea": {
          type: "GROUP",
name: "Login",
path: "Login",
pathFormatted: "group_login-99dea",
stats: {
    "name": "Login",
    "numberOfRequests": {
        "total": "11247",
        "ok": "0",
        "ko": "11247"
    },
    "minResponseTime": {
        "total": "384",
        "ok": "-",
        "ko": "384"
    },
    "maxResponseTime": {
        "total": "3140",
        "ok": "-",
        "ko": "3140"
    },
    "meanResponseTime": {
        "total": "658",
        "ok": "-",
        "ko": "658"
    },
    "standardDeviation": {
        "total": "155",
        "ok": "-",
        "ko": "155"
    },
    "percentiles1": {
        "total": "622",
        "ok": "-",
        "ko": "622"
    },
    "percentiles2": {
        "total": "691",
        "ok": "-",
        "ko": "691"
    },
    "percentiles3": {
        "total": "923",
        "ok": "-",
        "ko": "923"
    },
    "percentiles4": {
        "total": "1254",
        "ok": "-",
        "ko": "1254"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 0,
    "percentage": 0
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 11247,
    "percentage": 100
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "-",
        "ko": "2.894"
    }
},
contents: {
"req_post--login-pl-0234f": {
        type: "REQUEST",
        name: "POST /login.pl",
path: "Login / POST /login.pl",
pathFormatted: "req_login---post--l-3ad61",
stats: {
    "name": "POST /login.pl",
    "numberOfRequests": {
        "total": "11249",
        "ok": "11249",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2250",
        "ok": "2250",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "223",
        "ok": "223",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "79",
        "ok": "79",
        "ko": "-"
    },
    "percentiles1": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "percentiles2": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "percentiles3": {
        "total": "317",
        "ok": "317",
        "ko": "-"
    },
    "percentiles4": {
        "total": "423",
        "ok": "423",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11217,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 20,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 12,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.895",
        "ok": "2.895",
        "ko": "-"
    }
}
    },"req_get--nav-pl-4f0ee": {
        type: "REQUEST",
        name: "GET /nav.pl",
path: "Login / GET /nav.pl",
pathFormatted: "req_login---get--na-b767e",
stats: {
    "name": "GET /nav.pl",
    "numberOfRequests": {
        "total": "11248",
        "ok": "11248",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "125",
        "ok": "125",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2154",
        "ok": "2154",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "65",
        "ok": "65",
        "ko": "-"
    },
    "percentiles1": {
        "total": "201",
        "ok": "201",
        "ko": "-"
    },
    "percentiles2": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles3": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles4": {
        "total": "414",
        "ok": "414",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11239,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 8,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 1,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
}
    },"req_get--login-pl-06e7c": {
        type: "REQUEST",
        name: "GET /login.pl",
path: "Login / GET /login.pl",
pathFormatted: "req_login---get--lo-d1dba",
stats: {
    "name": "GET /login.pl",
    "numberOfRequests": {
        "total": "11247",
        "ok": "11247",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2149",
        "ok": "2149",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "77",
        "ok": "77",
        "ko": "-"
    },
    "percentiles1": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "percentiles2": {
        "total": "245",
        "ok": "245",
        "ko": "-"
    },
    "percentiles3": {
        "total": "323",
        "ok": "323",
        "ko": "-"
    },
    "percentiles4": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11220,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 17,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 10,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
}
    }
}

     },"group_open-flights-57e21": {
          type: "GROUP",
name: "Open flights",
path: "Open flights",
pathFormatted: "group_open-flights-57e21",
stats: {
    "name": "Open flights",
    "numberOfRequests": {
        "total": "11246",
        "ok": "11246",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "390",
        "ok": "390",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "3120",
        "ok": "3120",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "658",
        "ok": "658",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "156",
        "ok": "156",
        "ko": "-"
    },
    "percentiles1": {
        "total": "623",
        "ok": "623",
        "ko": "-"
    },
    "percentiles2": {
        "total": "698",
        "ok": "698",
        "ko": "-"
    },
    "percentiles3": {
        "total": "938",
        "ok": "938",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1267",
        "ok": "1267",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9924,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1178,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 144,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
},
contents: {
"req_get--welcome-pl-da0b1": {
        type: "REQUEST",
        name: "GET /welcome.pl",
path: "Open flights / GET /welcome.pl",
pathFormatted: "req_open-flights----fed1b",
stats: {
    "name": "GET /welcome.pl",
    "numberOfRequests": {
        "total": "11247",
        "ok": "11247",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "124",
        "ok": "124",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2276",
        "ok": "2276",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "76",
        "ok": "76",
        "ko": "-"
    },
    "percentiles1": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "percentiles2": {
        "total": "246",
        "ok": "246",
        "ko": "-"
    },
    "percentiles3": {
        "total": "319",
        "ok": "319",
        "ko": "-"
    },
    "percentiles4": {
        "total": "431",
        "ok": "431",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11223,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 18,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
}
    },"req_get--nav-pl-4f0ee": {
        type: "REQUEST",
        name: "GET /nav.pl",
path: "Open flights / GET /nav.pl",
pathFormatted: "req_open-flights----08549",
stats: {
    "name": "GET /nav.pl",
    "numberOfRequests": {
        "total": "11246",
        "ok": "11246",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1872",
        "ok": "1872",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "216",
        "ok": "216",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "percentiles1": {
        "total": "203",
        "ok": "203",
        "ko": "-"
    },
    "percentiles2": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles3": {
        "total": "322",
        "ok": "322",
        "ko": "-"
    },
    "percentiles4": {
        "total": "430",
        "ok": "430",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11225,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 15,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
}
    },"req_get--reservatio-0a71b": {
        type: "REQUEST",
        name: "GET /reservations.pl-welcome",
path: "Open flights / GET /reservations.pl-welcome",
pathFormatted: "req_open-flights----d0dd2",
stats: {
    "name": "GET /reservations.pl-welcome",
    "numberOfRequests": {
        "total": "11246",
        "ok": "11246",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2129",
        "ok": "2129",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "225",
        "ok": "225",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "71",
        "ok": "71",
        "ko": "-"
    },
    "percentiles1": {
        "total": "213",
        "ok": "213",
        "ko": "-"
    },
    "percentiles2": {
        "total": "250",
        "ok": "250",
        "ko": "-"
    },
    "percentiles3": {
        "total": "327",
        "ok": "327",
        "ko": "-"
    },
    "percentiles4": {
        "total": "443",
        "ok": "443",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11225,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.894",
        "ok": "2.894",
        "ko": "-"
    }
}
    }
}

     },"group_set-flight-pref-926c8": {
          type: "GROUP",
name: "Set flight preferences",
path: "Set flight preferences",
pathFormatted: "group_set-flight-pref-926c8",
stats: {
    "name": "Set flight preferences",
    "numberOfRequests": {
        "total": "11244",
        "ok": "11244",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "405",
        "ok": "405",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2890",
        "ok": "2890",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "654",
        "ok": "654",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "157",
        "ok": "157",
        "ko": "-"
    },
    "percentiles1": {
        "total": "617",
        "ok": "617",
        "ko": "-"
    },
    "percentiles2": {
        "total": "693",
        "ok": "693",
        "ko": "-"
    },
    "percentiles3": {
        "total": "927",
        "ok": "927",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1296",
        "ok": "1296",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9989,
    "percentage": 89
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1095,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 160,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
},
contents: {
"req_post--reservati-4549a": {
        type: "REQUEST",
        name: "POST /reservations.pl-direction",
path: "Set flight preferences / POST /reservations.pl-direction",
pathFormatted: "req_set-flight-pref-31f24",
stats: {
    "name": "POST /reservations.pl-direction",
    "numberOfRequests": {
        "total": "11244",
        "ok": "11244",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2174",
        "ok": "2174",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "217",
        "ok": "217",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "percentiles1": {
        "total": "202",
        "ok": "202",
        "ko": "-"
    },
    "percentiles2": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "percentiles3": {
        "total": "321",
        "ok": "321",
        "ko": "-"
    },
    "percentiles4": {
        "total": "442",
        "ok": "442",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11222,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    },"req_post--reservati-e5f7c": {
        type: "REQUEST",
        name: "POST /reservations.pl-seat",
path: "Set flight preferences / POST /reservations.pl-seat",
pathFormatted: "req_set-flight-pref-cb5da",
stats: {
    "name": "POST /reservations.pl-seat",
    "numberOfRequests": {
        "total": "11244",
        "ok": "11244",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "132",
        "ok": "132",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1526",
        "ok": "1526",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "218",
        "ok": "218",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "69",
        "ok": "69",
        "ko": "-"
    },
    "percentiles1": {
        "total": "205",
        "ok": "205",
        "ko": "-"
    },
    "percentiles2": {
        "total": "239",
        "ok": "239",
        "ko": "-"
    },
    "percentiles3": {
        "total": "320",
        "ok": "320",
        "ko": "-"
    },
    "percentiles4": {
        "total": "430",
        "ok": "430",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11222,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 17,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    },"req_post--reservati-834f6": {
        type: "REQUEST",
        name: "POST /reservations.pl-address",
path: "Set flight preferences / POST /reservations.pl-address",
pathFormatted: "req_set-flight-pref-62ca2",
stats: {
    "name": "POST /reservations.pl-address",
    "numberOfRequests": {
        "total": "11244",
        "ok": "11244",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "133",
        "ok": "133",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2144",
        "ok": "2144",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "220",
        "ok": "220",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "76",
        "ok": "76",
        "ko": "-"
    },
    "percentiles1": {
        "total": "206",
        "ok": "206",
        "ko": "-"
    },
    "percentiles2": {
        "total": "244",
        "ok": "244",
        "ko": "-"
    },
    "percentiles3": {
        "total": "324",
        "ok": "324",
        "ko": "-"
    },
    "percentiles4": {
        "total": "438",
        "ok": "438",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11224,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 12,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 8,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    }
}

     },"group_open-home-page-38ec6": {
          type: "GROUP",
name: "Open home page",
path: "Open home page",
pathFormatted: "group_open-home-page-38ec6",
stats: {
    "name": "Open home page",
    "numberOfRequests": {
        "total": "11242",
        "ok": "11242",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "385",
        "ok": "385",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2819",
        "ok": "2819",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "654",
        "ok": "654",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "158",
        "ok": "158",
        "ko": "-"
    },
    "percentiles1": {
        "total": "618",
        "ok": "618",
        "ko": "-"
    },
    "percentiles2": {
        "total": "699",
        "ok": "699",
        "ko": "-"
    },
    "percentiles3": {
        "total": "934",
        "ok": "934",
        "ko": "-"
    },
    "percentiles4": {
        "total": "1274",
        "ok": "1274",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 9936,
    "percentage": 88
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 1146,
    "percentage": 10
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 160,
    "percentage": 1
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
},
contents: {
"req_get--welcome-pl-da0b1": {
        type: "REQUEST",
        name: "GET /welcome.pl",
path: "Open home page / GET /welcome.pl",
pathFormatted: "req_open-home-page--5df8f",
stats: {
    "name": "GET /welcome.pl",
    "numberOfRequests": {
        "total": "11244",
        "ok": "11244",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "124",
        "ok": "124",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2173",
        "ok": "2173",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "211",
        "ok": "211",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "75",
        "ok": "75",
        "ko": "-"
    },
    "percentiles1": {
        "total": "199",
        "ok": "199",
        "ko": "-"
    },
    "percentiles2": {
        "total": "234",
        "ok": "234",
        "ko": "-"
    },
    "percentiles3": {
        "total": "315",
        "ok": "315",
        "ko": "-"
    },
    "percentiles4": {
        "total": "443",
        "ok": "442",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11222,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 16,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 6,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    },"req_get--nav-pl-4f0ee": {
        type: "REQUEST",
        name: "GET /nav.pl",
path: "Open home page / GET /nav.pl",
pathFormatted: "req_open-home-page--0dc70",
stats: {
    "name": "GET /nav.pl",
    "numberOfRequests": {
        "total": "11243",
        "ok": "11243",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2255",
        "ok": "2255",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "221",
        "ok": "221",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "73",
        "ok": "73",
        "ko": "-"
    },
    "percentiles1": {
        "total": "209",
        "ok": "209",
        "ko": "-"
    },
    "percentiles2": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "percentiles3": {
        "total": "325",
        "ok": "325",
        "ko": "-"
    },
    "percentiles4": {
        "total": "442",
        "ok": "442",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11223,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 17,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 3,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    },"req_get--login-pl-06e7c": {
        type: "REQUEST",
        name: "GET /login.pl",
path: "Open home page / GET /login.pl",
pathFormatted: "req_open-home-page--4423f",
stats: {
    "name": "GET /login.pl",
    "numberOfRequests": {
        "total": "11242",
        "ok": "11242",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "126",
        "ok": "126",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "1819",
        "ok": "1819",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "222",
        "ok": "222",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "72",
        "ok": "72",
        "ko": "-"
    },
    "percentiles1": {
        "total": "210",
        "ok": "210",
        "ko": "-"
    },
    "percentiles2": {
        "total": "249",
        "ok": "249",
        "ko": "-"
    },
    "percentiles3": {
        "total": "328",
        "ok": "328",
        "ko": "-"
    },
    "percentiles4": {
        "total": "446",
        "ok": "446",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11224,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 13,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 5,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.893",
        "ok": "2.893",
        "ko": "-"
    }
}
    }
}

     },"req_get--webtours-a0f3c": {
        type: "REQUEST",
        name: "GET /webtours",
path: "GET /webtours",
pathFormatted: "req_get--webtours-a0f3c",
stats: {
    "name": "GET /webtours",
    "numberOfRequests": {
        "total": "11250",
        "ok": "11250",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "211",
        "ok": "211",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "616",
        "ok": "616",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "241",
        "ok": "241",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "14",
        "ok": "14",
        "ko": "-"
    },
    "percentiles1": {
        "total": "240",
        "ok": "240",
        "ko": "-"
    },
    "percentiles2": {
        "total": "247",
        "ok": "247",
        "ko": "-"
    },
    "percentiles3": {
        "total": "259",
        "ok": "259",
        "ko": "-"
    },
    "percentiles4": {
        "total": "271",
        "ok": "271",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11250,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 0,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.895",
        "ok": "2.895",
        "ko": "-"
    }
}
    },"req_get--webtours-r-f575f": {
        type: "REQUEST",
        name: "GET /webtours Redirect 1",
path: "GET /webtours Redirect 1",
pathFormatted: "req_get--webtours-r-f575f",
stats: {
    "name": "GET /webtours Redirect 1",
    "numberOfRequests": {
        "total": "11249",
        "ok": "11249",
        "ko": "0"
    },
    "minResponseTime": {
        "total": "103",
        "ok": "103",
        "ko": "-"
    },
    "maxResponseTime": {
        "total": "2013",
        "ok": "2013",
        "ko": "-"
    },
    "meanResponseTime": {
        "total": "122",
        "ok": "122",
        "ko": "-"
    },
    "standardDeviation": {
        "total": "65",
        "ok": "65",
        "ko": "-"
    },
    "percentiles1": {
        "total": "116",
        "ok": "116",
        "ko": "-"
    },
    "percentiles2": {
        "total": "120",
        "ok": "120",
        "ko": "-"
    },
    "percentiles3": {
        "total": "127",
        "ok": "127",
        "ko": "-"
    },
    "percentiles4": {
        "total": "270",
        "ok": "270",
        "ko": "-"
    },
    "group1": {
    "name": "t < 800 ms",
    "count": 11221,
    "percentage": 100
},
    "group2": {
    "name": "800 ms < t < 1200 ms",
    "count": 19,
    "percentage": 0
},
    "group3": {
    "name": "t > 1200 ms",
    "count": 9,
    "percentage": 0
},
    "group4": {
    "name": "failed",
    "count": 0,
    "percentage": 0
},
    "meanNumberOfRequestsPerSecond": {
        "total": "2.895",
        "ok": "2.895",
        "ko": "-"
    }
}
    }
}

}

function fillStats(stat){
    $("#numberOfRequests").append(stat.numberOfRequests.total);
    $("#numberOfRequestsOK").append(stat.numberOfRequests.ok);
    $("#numberOfRequestsKO").append(stat.numberOfRequests.ko);

    $("#minResponseTime").append(stat.minResponseTime.total);
    $("#minResponseTimeOK").append(stat.minResponseTime.ok);
    $("#minResponseTimeKO").append(stat.minResponseTime.ko);

    $("#maxResponseTime").append(stat.maxResponseTime.total);
    $("#maxResponseTimeOK").append(stat.maxResponseTime.ok);
    $("#maxResponseTimeKO").append(stat.maxResponseTime.ko);

    $("#meanResponseTime").append(stat.meanResponseTime.total);
    $("#meanResponseTimeOK").append(stat.meanResponseTime.ok);
    $("#meanResponseTimeKO").append(stat.meanResponseTime.ko);

    $("#standardDeviation").append(stat.standardDeviation.total);
    $("#standardDeviationOK").append(stat.standardDeviation.ok);
    $("#standardDeviationKO").append(stat.standardDeviation.ko);

    $("#percentiles1").append(stat.percentiles1.total);
    $("#percentiles1OK").append(stat.percentiles1.ok);
    $("#percentiles1KO").append(stat.percentiles1.ko);

    $("#percentiles2").append(stat.percentiles2.total);
    $("#percentiles2OK").append(stat.percentiles2.ok);
    $("#percentiles2KO").append(stat.percentiles2.ko);

    $("#percentiles3").append(stat.percentiles3.total);
    $("#percentiles3OK").append(stat.percentiles3.ok);
    $("#percentiles3KO").append(stat.percentiles3.ko);

    $("#percentiles4").append(stat.percentiles4.total);
    $("#percentiles4OK").append(stat.percentiles4.ok);
    $("#percentiles4KO").append(stat.percentiles4.ko);

    $("#meanNumberOfRequestsPerSecond").append(stat.meanNumberOfRequestsPerSecond.total);
    $("#meanNumberOfRequestsPerSecondOK").append(stat.meanNumberOfRequestsPerSecond.ok);
    $("#meanNumberOfRequestsPerSecondKO").append(stat.meanNumberOfRequestsPerSecond.ko);
}
